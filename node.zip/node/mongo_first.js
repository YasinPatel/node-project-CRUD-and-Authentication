var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost/EmployeeDB';

MongoClient.connect(url,function(err,db){
    if (err) throw err;
    var myobj = { name: "Company Inc", address: "Highway 37" };
    insertFunction(db,myobj,function(err,reply){
        db.close();
    });


});


function insertFunction(db,myobj,callback){
  db.collection("customers").insertOne(myobj, function(err, res) {
    if (err) callback(err,null);
    console.log("1 document inserted");
    callback(null,res);
  });
}
