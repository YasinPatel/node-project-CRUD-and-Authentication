const express = require('express')
const bodyParser= require('body-parser')
const app = express()

app.use(bodyParser.urlencoded({extended: true}))
app.set('view engine', 'ejs')

var User = require('../models/User');

// index page of users
app.get('/',function(req,res){
  User.find({},function(err,users){
    if (err) throw err;
    res.render('users/index.ejs', {users: users})
  });
});

// add page of users
app.get('/add',function(req,res){
  res.render('users/add.ejs')
});

// add page of users
app.post('/add',(req,res) => {
  var body = req.body;
  var user = new User(req.body);

  user.save(function(err) {
    if (err) throw err;
  });
  res.redirect('/user')
});

// update page of users
app.get('/update/:id',function(req,res){
    User.findById(req.params.id, function(err, user) {
     if (err)
         res.send(err);
     res.render('users/update.ejs', {user: user})
     });
});

//update user data
app.post('/update/:id',function(req,res){
  User.findById(req.params.id, function(err, user) {
     if (err)
         res.send(err);

    user.name=req.body.name;
    user.email_id=req.body.email_id;

    user.save(function(err){
      if (err) throw err;
    })
    res.redirect('/user')
   });
});

// view user data
app.get('/:id',function(req,res){
    User.findById(req.params.id, function(err, user) {
      if (err)
          res.send(err);
      res.render('users/view.ejs', {user: user})
     });
});


// delete user data
app.post('/del/:id',function(req,res){

  User.remove({
    _id: req.params.id
  },function(err){
    if (err)
        res.send(err);
  });

  // 2nd way
  // User.findByIdAndRemove(req.params.id, function(err) {
  //   if (err) throw err;
  // });

  res.redirect('/user')
});
module.exports = app
