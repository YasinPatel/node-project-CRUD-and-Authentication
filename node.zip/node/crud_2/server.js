const express = require('express')
const bodyParser= require('body-parser')
const serverapp = express()

serverapp.use(bodyParser.urlencoded({extended: true}))
serverapp.set('view engine', 'ejs') // get information from html forms

var user = require(__dirname +'/controllers/UserController');

serverapp.get('/',function(req,res) // home page
{
  res.sendFile(__dirname + '/views/index.html')
});

serverapp.use('/user', user)

serverapp.get('*',function(req,res) // 404 page
{
  res.sendFile(__dirname + '/views/404.html')
});

var server = serverapp.listen(8081, function (req,res) {
  console.log("working");
})
