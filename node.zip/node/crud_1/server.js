const express = require('express')
const bodyParser= require('body-parser')
const app = express()
const MongoClient = require('mongodb').MongoClient

app.use(bodyParser.urlencoded({extended: true}))
app.set('view engine', 'ejs')

var url = 'mongodb://localhost/testDB';
var db;
MongoClient.connect(url,function(err,db1){
    if (err) throw err;
    db=db1
});

app.get('/',function(req,res)
{
  db.collection('data').find().toArray(function(err, results) {
  res.render('index.ejs', {quotes: results})
  })
});

app.get('/add',function(req,res)
{
  res.sendFile(__dirname + '/views/add.html')
});

app.post('/add', (req, res) => {
  db.collection('data').save(req.body, (err, result) => {
      if (err) return console.log(err)
      res.redirect('/')
    })
})

var server = app.listen(8081, function (req,res) {
  console.log("working");
})
